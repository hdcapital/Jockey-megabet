"""Official Betfair Exchange API adapter (external probability benchmark).

Uses the documented Betting API (JSON-RPC) with an application key and a
session token obtained from the identity SSO endpoint. Credentials come from
environment variables only (see ``.env.example``); nothing is ever written
to the repository or logs.

Probability methodology (Model B)
---------------------------------
For each runner we record best available back price, best available lay
price and visible available volume, then derive:

* both sides present and relative spread <= ``BETFAIR_MAX_RELATIVE_SPREAD``:
  probability = 1 / midpoint(back, lay), marked reliable when the market's
  total available-to-back volume >= ``BETFAIR_MIN_LIQUIDITY``.
* one side missing or the spread too wide: probability derived from the back
  price alone and marked unreliable (kept for the record, excluded from
  consensus by default).
* no usable prices: probability None ("unavailable"), never invented.
* delayed application key (every book reports zero matched volume): the
  liquidity gate cannot be met, so a runner is reliable when the spread is
  within ``BETFAIR_DELAYED_MAX_RELATIVE_SPREAD`` and its detail says so.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any

from app.config import get_settings
from app.http import ArchivingClient, SourceUnavailableError

log = logging.getLogger(__name__)

SOURCE = "betfair"

# Betfair names Australian runners "7. Zoustar" (saddlecloth, dot, name).
_CLOTH_PREFIX = re.compile(r"^\s*(\d+)\s*[.)-]\s*(.+?)\s*$")


def split_runner_name(raw: str) -> tuple[int | None, str]:
    """``"7. Zoustar"`` -> ``(7, "Zoustar")``; ``"Zoustar"`` -> ``(None, "Zoustar")``."""
    m = _CLOTH_PREFIX.match(raw or "")
    if m:
        return int(m.group(1)), m.group(2)
    return None, (raw or "").strip()


def market_is_delayed(book: dict[str, Any]) -> bool:
    """True when a market book carries no matched volume anywhere.

    A real Australian win market always has *some* matched volume once it
    is open. None at all, on the market and on every runner, is the
    signature of a delayed application key rather than of an empty market.
    """
    if book.get("totalMatched"):
        return False
    for r in book.get("runners", []) or []:
        if r.get("totalMatched"):
            return False
    return True


class BetfairNotConfiguredError(Exception):
    """Raised when Betfair credentials are absent — a normal, reported state."""


@dataclass
class BetfairRunnerQuote:
    market_id: str
    selection_id: int
    runner_name: str
    best_back: float | None
    best_lay: float | None
    back_volume: float | None
    lay_volume: float | None
    total_matched: float | None
    market_status: str
    fetched_at: datetime
    probability: float | None = None
    reliable: bool = False
    detail: str = ""
    cloth_number: int | None = None  # parsed from "7. Zoustar", None if absent


@dataclass
class BetfairMarket:
    market_id: str
    market_name: str
    venue: str | None
    market_start: datetime | None
    race_number: int | None = None
    runners: list[BetfairRunnerQuote] = field(default_factory=list)
    book_status: str | None = None  # None until a book was fetched
    delayed: bool = False  # prices came from a delayed application key


def derive_probability(
    best_back: float | None,
    best_lay: float | None,
    total_matched: float | None,
    min_liquidity: float,
    max_relative_spread: float,
    delayed: bool = False,
    delayed_max_relative_spread: float = 0.10,
) -> tuple[float | None, bool, str]:
    """(probability, reliable, detail) from exchange prices — see module doc.

    ``delayed`` switches to the spread-only rule: matched volume is not
    reported by a delayed key, so it cannot be a condition of reliability.
    """
    if delayed:
        max_relative_spread = delayed_max_relative_spread
    if best_back is not None and best_back <= 1.0:
        best_back = None
    if best_lay is not None and best_lay <= 1.0:
        best_lay = None
    if best_back is None and best_lay is None:
        return None, False, "no exchange prices available"
    if best_back is not None and best_lay is not None:
        spread = (best_lay - best_back) / best_back
        if spread < 0:
            return None, False, f"crossed book (back {best_back} > lay {best_lay})"
        if spread <= max_relative_spread:
            mid = (best_back + best_lay) / 2.0
            if delayed:
                return 1.0 / mid, True, "midpoint of best back/lay; delayed key, spread-only"
            liquid = total_matched is not None and total_matched >= min_liquidity
            detail = "midpoint of best back/lay" + (
                "" if liquid else f"; thin market (matched {total_matched})"
            )
            return 1.0 / mid, liquid, detail
        return (
            1.0 / best_back,
            False,
            f"spread {spread:.1%} too wide for midpoint; using best back",
        )
    side = best_back if best_back is not None else best_lay
    name = "back" if best_back is not None else "lay"
    return 1.0 / side, False, f"only best {name} available"


class BetfairClient:
    def __init__(self, client: ArchivingClient | None = None):
        self.settings = get_settings()
        if not (self.settings.betfair_app_key and self.settings.betfair_username):
            raise BetfairNotConfiguredError(
                "BETFAIR_APP_KEY / BETFAIR_USERNAME not set; Betfair benchmark disabled"
            )
        self.client = client or ArchivingClient(SOURCE)
        self._session_token: str | None = None

    def close(self) -> None:
        self.client.close()

    # -- auth -----------------------------------------------------------
    def login(self) -> None:
        s = self.settings
        if s.betfair_cert_file and s.betfair_key_file:
            url = f"{s.betfair_identity_cert_url}/api/certlogin"
        else:
            url = f"{s.betfair_identity_url}/api/login"
        result = self.client.post_json(
            url,
            data={"username": s.betfair_username, "password": s.betfair_password or ""},
            headers={
                "X-Application": s.betfair_app_key or "",
                "Content-Type": "application/x-www-form-urlencoded",
            },
        )
        body = result.json()
        token = body.get("token") or body.get("sessionToken")
        status = body.get("status") or body.get("loginStatus")
        if not token:
            raise SourceUnavailableError(
                SOURCE, url, f"login failed: {status or body}", result.status_code
            )
        self._session_token = token
        log.info("betfair: login ok")

    def _rpc(self, method: str, params: dict[str, Any], _retry: bool = True) -> Any:
        if self._session_token is None:
            self.login()
        s = self.settings
        result = self.client.post_json(
            s.betfair_api_url,
            json_body={
                "jsonrpc": "2.0",
                "method": f"SportsAPING/v1.0/{method}",
                "params": params,
                "id": 1,
            },
            headers={
                "X-Application": s.betfair_app_key or "",
                "X-Authentication": self._session_token or "",
                "Content-Type": "application/json",
            },
        )
        body = result.json()
        if "error" in body:
            # A session token lasts hours, not days. In a long loop the first
            # sign of expiry is this error code; one fresh login fixes it.
            text = json.dumps(body["error"])
            if _retry and ("INVALID_SESSION_INFORMATION" in text or "NO_SESSION" in text):
                log.warning("betfair: session expired, logging in again")
                self._session_token = None
                self.login()
                return self._rpc(method, params, _retry=False)
            raise SourceUnavailableError(
                SOURCE, s.betfair_api_url, f"{method} error: {body['error']}"
            )
        return body.get("result")

    # -- markets ---------------------------------------------------------
    #: listMarketCatalogue has a data-weight limit of 200 per request:
    #: RUNNER_DESCRIPTION weighs 1 per market and MARKET_DESCRIPTION another
    #: 1. A normal Australian day is ~110 WIN markets, so asking for both in
    #: one call (222) comes back TOO_MUCH_DATA and the exchange never engages
    #: (observed live 2026-09-19). MARKET_DESCRIPTION was never read by the
    #: parser; drop it, and ask in time windows so a big day stays under the
    #: limit too.
    CATALOGUE_WINDOW_HOURS = 6
    CATALOGUE_MAX_RESULTS = 200

    def list_au_win_markets(self, for_date: date) -> list[BetfairMarket]:
        """Australian thoroughbred WIN markets starting on the given date."""
        import re as _re

        start = datetime.combine(for_date, datetime.min.time(), tzinfo=timezone.utc)
        window_from = start - timedelta(hours=14)
        window_to = start + timedelta(hours=38)
        markets: list[BetfairMarket] = []
        seen: set[str] = set()
        cursor = window_from
        while cursor < window_to:
            chunk_to = min(cursor + timedelta(hours=self.CATALOGUE_WINDOW_HOURS), window_to)
            catalogue = self._rpc(
                "listMarketCatalogue",
                {
                    "filter": {
                        "eventTypeIds": ["7"],  # horse racing
                        "marketCountries": ["AU"],
                        "marketTypeCodes": ["WIN"],
                        "marketStartTime": {
                            "from": cursor.isoformat(),
                            "to": chunk_to.isoformat(),
                        },
                    },
                    "marketProjection": ["EVENT", "MARKET_START_TIME", "RUNNER_DESCRIPTION"],
                    "sort": "FIRST_TO_START",
                    "maxResults": self.CATALOGUE_MAX_RESULTS,
                },
            ) or []
            if len(catalogue) >= self.CATALOGUE_MAX_RESULTS:
                log.warning(
                    "betfair: catalogue window %s..%s hit maxResults=%d; some "
                    "markets may be missing", cursor, chunk_to, self.CATALOGUE_MAX_RESULTS,
                )
            for m in catalogue:
                if m["marketId"] in seen:
                    continue
                seen.add(m["marketId"])
                event = m.get("event") or {}
                start_str = m.get("marketStartTime")
                start_dt = (
                    datetime.fromisoformat(start_str.replace("Z", "+00:00"))
                    if isinstance(start_str, str)
                    else None
                )
                name = m.get("marketName", "")
                mm = _re.match(r"\s*R(\d+)", name)
                bm = BetfairMarket(
                    market_id=m["marketId"],
                    market_name=name,
                    venue=event.get("venue") or event.get("name"),
                    market_start=start_dt,
                    race_number=int(mm.group(1)) if mm else None,
                )
                bm._catalogue_runners = {  # type: ignore[attr-defined]
                    r["selectionId"]: r.get("runnerName", "")
                    for r in m.get("runners", [])
                }
                markets.append(bm)
            cursor = chunk_to
        log.info("betfair: %d AU win markets in catalogue", len(markets))
        return markets

    def fetch_market_books(self, markets: list[BetfairMarket]) -> None:
        """Populate runner quotes with live best back/lay via listMarketBook.

        Whether the key is delayed is decided once per call from every book
        together (see :func:`market_is_delayed`), never from a single thin
        market, unless ``BETFAIR_KEY_DELAYED`` forces it.
        """
        s = self.settings
        fetched_at = datetime.now(timezone.utc)
        books_by_id: dict[str, dict[str, Any]] = {}
        for i in range(0, len(markets), 25):  # API weight limits
            chunk = markets[i : i + 25]
            books = self._rpc(
                "listMarketBook",
                {
                    "marketIds": [m.market_id for m in chunk],
                    "priceProjection": {"priceData": ["EX_BEST_OFFERS"]},
                },
            ) or []
            for b in books:
                books_by_id[b["marketId"]] = b

        forced = (s.betfair_key_delayed or "auto").strip().lower()
        if forced in ("true", "1", "yes"):
            delayed = True
        elif forced in ("false", "0", "no"):
            delayed = False
        else:
            open_books = [b for b in books_by_id.values() if b.get("status") == "OPEN"]
            delayed = bool(open_books) and all(market_is_delayed(b) for b in open_books)
        if delayed:
            log.warning(
                "betfair: no matched volume on any of %d open books — treating the "
                "application key as DELAYED (spread-only reliability, max %.0f%%). "
                "Set BETFAIR_KEY_DELAYED=false to override.",
                len(books_by_id), s.betfair_delayed_max_relative_spread * 100,
            )

        missing = 0
        for market in markets:
            book = books_by_id.get(market.market_id)
            market.delayed = delayed
            if not book:
                missing += 1
                log.warning(
                    "betfair: no book returned for %s %s (%s)",
                    market.venue, market.market_name, market.market_id,
                )
                continue
            status = book.get("status", "UNKNOWN")
            market.book_status = status
            names = getattr(market, "_catalogue_runners", {})
            active = [r for r in book.get("runners", []) if r.get("status") in (None, "ACTIVE")]
            if not active:
                log.warning(
                    "betfair: %s %s book is %s with no active runners "
                    "(%d in book, %d in catalogue)",
                    market.venue, market.market_name, status,
                    len(book.get("runners", [])), len(names),
                )
            for r in active:
                ex = r.get("ex") or {}
                backs = ex.get("availableToBack") or []
                lays = ex.get("availableToLay") or []
                best_back = backs[0]["price"] if backs else None
                back_vol = backs[0]["size"] if backs else None
                best_lay = lays[0]["price"] if lays else None
                lay_vol = lays[0]["size"] if lays else None
                total = r.get("totalMatched") or book.get("totalMatched")
                prob, reliable, detail = derive_probability(
                    best_back,
                    best_lay,
                    total,
                    s.betfair_min_liquidity,
                    s.betfair_max_relative_spread,
                    delayed=delayed,
                    delayed_max_relative_spread=s.betfair_delayed_max_relative_spread,
                )
                raw_name = names.get(r["selectionId"], "")
                cloth, _ = split_runner_name(raw_name)
                market.runners.append(
                    BetfairRunnerQuote(
                        market_id=market.market_id,
                        selection_id=r["selectionId"],
                        runner_name=raw_name,
                        best_back=best_back,
                        best_lay=best_lay,
                        back_volume=back_vol,
                        lay_volume=lay_vol,
                        total_matched=total,
                        market_status=status,
                        fetched_at=fetched_at,
                        probability=prob,
                        reliable=reliable,
                        detail=detail,
                        cloth_number=cloth,
                    )
                )
        if missing:
            log.warning("betfair: %d of %d markets came back without a book", missing, len(markets))
